package com.example.hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView text1;
    private TextView text2;
    private EditText edit1;
    private EditText edit2;
    private EditText edit3;
    private EditText edit4;
    private Button button1;
    private Button button2;
    private static String m;
    private static String m2;
    private static String m3;
    private static String m4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text1 = findViewById(R.id.textView);
        text2 = findViewById(R.id.textView2);
        edit1 = findViewById(R.id.edit1);
        edit2 = findViewById(R.id.edit2);
        edit3 = findViewById(R.id.edit3);
        edit4 = findViewById(R.id.edit4);
        button1 = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);

        button1.setOnClickListener(new View.OnClickListener() {// هنا نفتح الكليك ليسنر
            @Override
            public void onClick(View view) {
                m = edit1.getText().toString();
                m2 = edit2.getText().toString();
                m3 = edit3.getText().toString();
                m4 = edit4.getText().toString();
                int x = Integer.parseInt(m);
                int y = Integer.parseInt(m2);
                int n = Integer.parseInt(m3);
                int l = Integer.parseInt(m4);
                int result = x + y + n + l;

                String a = String.valueOf(result);

                text2.setText(a);


            }//هنا نغلق دالة الجمع
        });
        button2.setOnClickListener(new View.OnClickListener() {// هنا نفتح الكليك ليسنر
            @Override
            public void onClick(View view) {

              edit1.setText("");
                edit2.setText("");
                edit3.setText("");
                edit4.setText("");

            }//هنا نغلق دالة الجمع
        });
    }
}